create function information_schema."_pg_truetypmod"(pg_attribute, pg_type) returns integer
LANGUAGE SQL
AS $$
SELECT CASE WHEN $2.typtype = 'd' THEN $2.typtypmod ELSE $1.atttypmod END
$$;
